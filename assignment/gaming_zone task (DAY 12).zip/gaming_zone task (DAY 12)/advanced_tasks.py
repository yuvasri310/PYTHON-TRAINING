# advanced_tasks.py
import mysql.connector
from gaming_utils import get_connection

# Task 14: Log gameplay by name with validation
def log_gameplay_by_name():
    try:
        member_name = input("Enter member name: ")
        game_name = input("Enter game name: ")
        hours = int(input("Enter hours to play: "))

        conn = get_connection()
        if conn is None:
            return

        cursor = conn.cursor()
        cursor.execute("SELECT member_id, membership_type, hours_spent FROM Members WHERE name = %s", (member_name,))
        member = cursor.fetchone()
        if not member:
            print("Member not found.")
            return

        member_id, mem_type, spent = member

        cursor.execute("SELECT hours_allowed FROM Memberships WHERE membership_type = %s", (mem_type,))
        allowed = cursor.fetchone()[0]
        remaining = allowed - spent

        if remaining < hours:
            print(f"Not enough hours left. Remaining: {remaining}")
            return

        cursor.execute("SELECT game_id FROM Games WHERE game_name = %s", (game_name,))
        game = cursor.fetchone()
        if not game:
            print("Game not found.")
            return

        game_id = game[0]
        cursor.execute("INSERT INTO GamePlays (member_id, game_id, hours_played, play_date) VALUES (%s, %s, %s, CURDATE())", (member_id, game_id, hours))
        cursor.execute("UPDATE Members SET hours_spent = hours_spent + %s WHERE member_id = %s", (hours, member_id))
        conn.commit()
        print("Gameplay logged.")
        conn.close()
    except Exception as e:
        print("Error:", e)

# Task 15: Members who used > 75% of their hours
def high_usage_members():
    try:
        conn = get_connection()
        if conn is None:
            return

        cursor = conn.cursor()
        cursor.execute("""
            SELECT m.name, m.membership_type, m.hours_spent, ms.hours_allowed,
                   ROUND((m.hours_spent / ms.hours_allowed) * 100, 2) as usage_percent
            FROM Members m
            JOIN Memberships ms ON m.membership_type = ms.membership_type
            WHERE (m.hours_spent / ms.hours_allowed) > 0.75
        """)
        print("\nMembers who used more than 75% of hours:")
        for row in cursor.fetchall():
            print(f"{row[0]} | {row[1]} | {row[2]}/{row[3]} hrs ({row[4]}%)")
        conn.close()
    except Exception as e:
        print("Error:", e)

# Task 16: Detailed report of each member
def detailed_member_report():
    try:
        conn = get_connection()
        if conn is None:
            return

        cursor = conn.cursor()
        cursor.execute("""
            SELECT m.name, m.membership_type, COUNT(DISTINCT gp.game_id) AS games_played,
                   SUM(gp.hours_played) AS total_played,
                   (ms.hours_allowed - m.hours_spent) AS hours_left
            FROM Members m
            LEFT JOIN GamePlays gp ON m.member_id = gp.member_id
            JOIN Memberships ms ON m.membership_type = ms.membership_type
            GROUP BY m.member_id
        """)
        print("\nDetailed Member Report:")
        for row in cursor.fetchall():
            print(f"{row[0]} | {row[1]} | Games: {row[2]} | Hours Played: {row[3] or 0} | Hours Left: {row[4]}")
        conn.close()
    except Exception as e:
        print("Error:", e)

# Task 17: Members who have never played any game
def never_played_members():
    try:
        conn = get_connection()
        if conn is None:
            return

        cursor = conn.cursor()
        cursor.execute("""
            SELECT m.name FROM Members m
            LEFT JOIN GamePlays gp ON m.member_id = gp.member_id
            WHERE gp.member_id IS NULL
        """)
        print("\nMembers who have never played:")
        for row in cursor.fetchall():
            print(f"{row[0]}")
        conn.close()
    except Exception as e:
        print("Error:", e)