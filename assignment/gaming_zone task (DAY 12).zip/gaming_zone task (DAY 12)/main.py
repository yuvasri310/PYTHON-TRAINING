# main.py
from gamingzone_tasks import (
    list_games,
    list_members,
    list_members_by_type,
    member_hours_left,
    count_monthly_members,
    players_for_game,
    hours_for_game,
    most_played_game
)
from game_operations import (
    add_game,
    games_above_100,
    count_games_by_type
)
from member_operations import (
    register_member,
    log_gameplay,
    delete_inactive_member
)
from report_functions import (
    members_with_low_hours,
    members_played_multiple_games,
    remaining_hours_by_membership,
    total_income,
    most_active_member,
    top_3_played_games,
    member_game_report
)
from advanced_tasks import (
    log_gameplay_by_name,
    high_usage_members,
    detailed_member_report,
    never_played_members
)

def main_menu():
    while True:
        print("""
=== Gaming Zone Management ===
1. List all games
2. List all members
3. List members by type
4. Show member hours left
5. Count monthly members
6. How many people played a particular game
7. How many hours a particular game was played
8. Which game was played most
9. Add a new game
10. Register a new member
11. Log gameplay
12. Delete inactive member
13. Games with charges > ₹100/hr
14. Count of games by type
15. Members with < 10 hours left
16. Members who played > 2 games
17. Remaining hours by membership type
18. Total income earned
19. Most active member
20. Top 3 most played games
21. Member-wise game play report
22. Log gameplay by name (with validation)
23. Members who used > 75% of hours
24. Detailed member report
25. Members who never played
0. Exit
""")

        choice = input("Enter your choice: ")

        if choice == '1': list_games()
        elif choice == '2': list_members()
        elif choice == '3': list_members_by_type()
        elif choice == '4': member_hours_left()
        elif choice == '5': count_monthly_members()
        elif choice == '6':
            game_id = int(input("Enter game ID: "))
            players_for_game(game_id)
        elif choice == '7':
            game_id = int(input("Enter game ID: "))
            hours_for_game(game_id)
        elif choice == '8': most_played_game()
        elif choice == '9': add_game()
        elif choice == '10': register_member()
        elif choice == '11': log_gameplay()
        elif choice == '12': delete_inactive_member()
        elif choice == '13': games_above_100()
        elif choice == '14': count_games_by_type()
        elif choice == '15': members_with_low_hours()
        elif choice == '16': members_played_multiple_games()
        elif choice == '17': remaining_hours_by_membership()
        elif choice == '18': total_income()
        elif choice == '19': most_active_member()
        elif choice == '20': top_3_played_games()
        elif choice == '21': member_game_report()
        elif choice == '22': log_gameplay_by_name()
        elif choice == '23': high_usage_members()
        elif choice == '24': detailed_member_report()
        elif choice == '25': never_played_members()
        elif choice == '0':
            print("Exiting Gaming Zone Management. Goodbye!")
            break
        else:
            print("Invalid option. Please try again.")

if __name__ == '__main__':
    main_menu()
