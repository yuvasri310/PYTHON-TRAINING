# game_operations.py
import mysql.connector
from gaming_utils import get_connection

# Task 1: Add a new game to the Games table
def add_game():
    try:
        name = input("Enter game name: ")
        gtype = input("Enter game type: ")
        charge = float(input("Enter charge per hour: "))

        conn = get_connection()
        if conn is None:
            return

        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO Games (game_name, game_type, charge_per_hour)
            VALUES (%s, %s, %s)
        """, (name, gtype, charge))
        conn.commit()
        print("Game added successfully.")
        conn.close()
    except Exception as e:
        print("Error adding game:", e)

# Task 5: Display all games with charges above ₹100/hr
def games_above_100():
    try:
        conn = get_connection()
        if conn is None:
            return

        cursor = conn.cursor()
        cursor.execute("SELECT game_name, charge_per_hour FROM Games WHERE charge_per_hour > 100")
        print("\nGames with charge > ₹100/hr:")
        for row in cursor.fetchall():
            print(f"{row[0]} - ₹{row[1]}/hr")
        conn.close()
    except Exception as e:
        print("Error fetching games:", e)

# Task 6: Count how many games of each type exist
def count_games_by_type():
    try:
        conn = get_connection()
        if conn is None:
            return

        cursor = conn.cursor()
        cursor.execute("SELECT game_type, COUNT(*) FROM Games GROUP BY game_type")
        print("\nGame count by type:")
        for row in cursor.fetchall():
            print(f"{row[0]}: {row[1]} games")
        conn.close()
    except Exception as e:
        print("Error counting games:", e)
