# gaming_utils.py
import mysql.connector

def get_connection():
    try:
        return mysql.connector.connect(
            host='localhost',
            user='root',
            password='Yuvasri@310*', 
            database='gamingzone'
        )
    except mysql.connector.Error as err:
        print("Failed to connect to database:", err)
        return None
