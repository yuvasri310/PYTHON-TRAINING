# gamingzone_tasks.py
import mysql.connector
from datetime import date

def get_connection():
    return mysql.connector.connect(
        host='localhost', user='root', password='Yuvasri@310*', database='gamingzone'
    )

# 1) List the games available in zone
def list_games():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM Games")
    for row in cursor.fetchall():
        print(row)
    conn.close()

# 2) List the members registered
def list_members():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM Members")
    for row in cursor.fetchall():
        print(row)
    conn.close()

# 3) List yearly, monthly, daily members separately
def list_members_by_type(m_type):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM Members WHERE membership_type = %s", (m_type,))
    for row in cursor.fetchall():
        print(row)
    conn.close()

# 4) Show name of member with membership type and hours left
def member_hours_left():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT m.name, m.membership_type, ms.hours_allowed - m.hours_spent AS hours_left
        FROM Members m JOIN Memberships ms ON m.membership_type = ms.membership_type
    """)
    for row in cursor.fetchall():
        print(row)
    conn.close()

# 5) How many members registered monthly basis
def count_monthly_members():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM Members WHERE membership_type = 'Monthly'")
    print("Monthly Members:", cursor.fetchone()[0])
    conn.close()

# 6) How many people played a particular game
def players_for_game(game_id):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(DISTINCT member_id) FROM GamePlays WHERE game_id = %s", (game_id,))
    print("Players for game", game_id, ":", cursor.fetchone()[0])
    conn.close()

# 7) How many hours a particular game was played
def hours_for_game(game_id):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT SUM(hours_played) FROM GamePlays WHERE game_id = %s", (game_id,))
    print("Total hours played for game", game_id, ":", cursor.fetchone()[0])
    conn.close()

# 8) Which game was played most
def most_played_game():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT g.game_name, SUM(gp.hours_played) AS total_hours
        FROM GamePlays gp JOIN Games g ON gp.game_id = g.game_id
        GROUP BY gp.game_id
        ORDER BY total_hours DESC
        LIMIT 1
    """)
    print("Most Played Game:", cursor.fetchone())
    conn.close()
