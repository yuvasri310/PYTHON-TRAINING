# member_operations.py
import mysql.connector
from gaming_utils import get_connection

# Task 2: Register a new member with initial hours
def register_member():
    try:
        name = input("Enter member name: ")
        membership_type = input("Enter membership type (Yearly/Monthly/Daily): ")

        conn = get_connection()
        if conn is None:
            return

        cursor = conn.cursor()
        cursor.execute("SELECT hours_allowed FROM Memberships WHERE membership_type = %s", (membership_type,))
        result = cursor.fetchone()
        if result:
            hours_allowed = result[0]
            cursor.execute("""
                INSERT INTO Members (name, membership_type, hours_spent)
                VALUES (%s, %s, 0)
            """, (name, membership_type))
            conn.commit()
            print(f"Member '{name}' registered with {hours_allowed} allowed hours.")
        else:
            print("Invalid membership type.")
        conn.close()
    except Exception as e:
        print("Error registering member:", e)

# Task 3: Update member hours and log gameplay
def log_gameplay():
    try:
        member_id = int(input("Enter member ID: "))
        game_id = int(input("Enter game ID: "))
        hours = int(input("Enter hours played: "))

        conn = get_connection()
        if conn is None:
            return

        cursor = conn.cursor()
        cursor.execute("""
            SELECT ms.hours_allowed, m.hours_spent
            FROM Members m
            JOIN Memberships ms ON m.membership_type = ms.membership_type
            WHERE m.member_id = %s
        """, (member_id,))
        result = cursor.fetchone()

        if not result:
            print("Member not found.")
            return

        allowed, spent = result
        remaining = allowed - spent

        if hours > remaining:
            print(f"Not enough hours left. Remaining: {remaining}")
        else:
            cursor.execute("""
                INSERT INTO GamePlays (member_id, game_id, hours_played, play_date)
                VALUES (%s, %s, %s, CURDATE())
            """, (member_id, game_id, hours))
            cursor.execute("UPDATE Members SET hours_spent = hours_spent + %s WHERE member_id = %s", (hours, member_id))
            conn.commit()
            print("Gameplay logged successfully.")
        conn.close()
    except Exception as e:
        print("Error logging gameplay:", e)

# Task 4: Delete a member who hasn't played any game
def delete_inactive_member():
    try:
        member_id = int(input("Enter member ID to delete: "))

        conn = get_connection()
        if conn is None:
            return

        cursor = conn.cursor()
        cursor.execute("SELECT * FROM GamePlays WHERE member_id = %s", (member_id,))
        if cursor.fetchone():
            print("Cannot delete. Member has gameplay records.")
        else:
            cursor.execute("DELETE FROM Members WHERE member_id = %s", (member_id,))
            conn.commit()
            print("Member deleted successfully.")
        conn.close()
    except Exception as e:
        print("Error deleting member:", e)