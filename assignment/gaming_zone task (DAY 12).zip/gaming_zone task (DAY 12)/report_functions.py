# report_functions.py
import mysql.connector
from gaming_utils import get_connection

# Task 7: Members with < 10 hours remaining
def members_with_low_hours():
    try:
        conn = get_connection()
        if conn is None:
            return

        cursor = conn.cursor()
        cursor.execute("""
            SELECT m.name, m.membership_type, (ms.hours_allowed - m.hours_spent) AS hours_left
            FROM Members m
            JOIN Memberships ms ON m.membership_type = ms.membership_type
            WHERE (ms.hours_allowed - m.hours_spent) < 10
        """)
        print("\nMembers with < 10 hours remaining:")
        for row in cursor.fetchall():
            print(f"Name: {row[0]} | Type: {row[1]} | Hours Left: {row[2]}")
        conn.close()
    except Exception as e:
        print("Error:", e)

# Task 8: Members who played > 2 different games
def members_played_multiple_games():
    try:
        conn = get_connection()
        if conn is None:
            return

        cursor = conn.cursor()
        cursor.execute("""
            SELECT m.name, COUNT(DISTINCT gp.game_id) as games_played
            FROM Members m
            JOIN GamePlays gp ON m.member_id = gp.member_id
            GROUP BY m.member_id
            HAVING games_played > 2
        """)
        print("\nMembers who played more than 2 games:")
        for row in cursor.fetchall():
            print(f"{row[0]} - {row[1]} games")
        conn.close()
    except Exception as e:
        print("Error:", e)

# Task 9: Total hours remaining by membership type
def remaining_hours_by_membership():
    try:
        conn = get_connection()
        if conn is None:
            return

        cursor = conn.cursor()
        cursor.execute("""
            SELECT m.membership_type, SUM(ms.hours_allowed - m.hours_spent) AS total_remaining
            FROM Members m
            JOIN Memberships ms ON m.membership_type = ms.membership_type
            GROUP BY m.membership_type
        """)
        print("\nRemaining Hours by Membership Type:")
        for row in cursor.fetchall():
            print(f"{row[0]}: {row[1]} hours left")
        conn.close()
    except Exception as e:
        print("Error:", e)

# Task 10: Total income from game plays
def total_income():
    try:
        conn = get_connection()
        if conn is None:
            return

        cursor = conn.cursor()
        cursor.execute("""
            SELECT SUM(g.charge_per_hour * gp.hours_played)
            FROM GamePlays gp
            JOIN Games g ON gp.game_id = g.game_id
        """)
        result = cursor.fetchone()
        print("\nTotal Income: ₹", result[0] if result and result[0] else 0)
        conn.close()
    except Exception as e:
        print("Error:", e)

# Task 11: Most active member (max hours spent)
def most_active_member():
    try:
        conn = get_connection()
        if conn is None:
            return

        cursor = conn.cursor()
        cursor.execute("""
            SELECT name, hours_spent FROM Members
            ORDER BY hours_spent DESC
            LIMIT 1
        """)
        result = cursor.fetchone()
        print(f"\nMost Active Member: {result[0]} - {result[1]} hours")
        conn.close()
    except Exception as e:
        print("Error:", e)

# Task 12: Top 3 most played games
def top_3_played_games():
    try:
        conn = get_connection()
        if conn is None:
            return

        cursor = conn.cursor()
        cursor.execute("""
            SELECT g.game_name, SUM(gp.hours_played) AS total
            FROM GamePlays gp
            JOIN Games g ON gp.game_id = g.game_id
            GROUP BY gp.game_id
            ORDER BY total DESC
            LIMIT 3
        """)
        print("\nTop 3 Most Played Games:")
        for row in cursor.fetchall():
            print(f"{row[0]} - {row[1]} hours")
        conn.close()
    except Exception as e:
        print("Error:", e)

# Task 13: Report - total hours played per member per game
def member_game_report():
    try:
        conn = get_connection()
        if conn is None:
            return

        cursor = conn.cursor()
        cursor.execute("""
            SELECT m.name, g.game_name, SUM(gp.hours_played) AS total_hours
            FROM GamePlays gp
            JOIN Members m ON gp.member_id = m.member_id
            JOIN Games g ON gp.game_id = g.game_id
            GROUP BY m.member_id, g.game_id
        """)
        print("\nMember Game Report:")
        for row in cursor.fetchall():
            print(f"{row[0]} | {row[1]} | {row[2]} hours")
        conn.close()
    except Exception as e:
        print("Error:", e)