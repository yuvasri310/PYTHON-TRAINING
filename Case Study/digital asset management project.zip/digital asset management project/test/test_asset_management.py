import pytest
from dao.AssetManagementServiceImpl import AssetManagementServiceImpl
from entity.Asset import Asset

service = AssetManagementServiceImpl()

def test_add_asset_success():
    asset = Asset(
        name="Test Laptop",
        type="Laptop",
        serial_number="TEST123456",
        purchase_date="2024-06-01",
        location="Test Location",
        status="in use",
        owner_id=1
    )
    assert service.addAsset(asset) == True

def test_perform_maintenance_success():
    result = service.performMaintenance(
        asset_id=1,
        maintenance_date="2024-06-20",
        description="Routine check-up",
        cost=300.0
    )
    assert result == True

def test_reserve_asset_success():
    result = service.reserveAsset(
        asset_id=1,
        employee_id=2,
        reservation_date="2024-06-20",
        start_date="2024-06-21",
        end_date="2024-06-25"
    )
    assert result == True

def test_invalid_asset_delete():
    result = service.deleteAsset(asset_id=99999)  # Assuming this ID doesn’t exist
    assert result == False
