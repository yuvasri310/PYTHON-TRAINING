class AssetNotMaintainException(Exception):
    def __init__(self,message="Asset has not been maintained in the last 2 years."):
        self.message=message
        super().__init__(self.message)
