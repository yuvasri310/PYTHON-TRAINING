import mysql.connector
from util.DBPropertyUtil import DBPropertyUtil

class DBConnUtil:
    @staticmethod
    def getConnection():
        try:
            db_config = DBPropertyUtil.getPropertyString('util/db.properties')
            conn = mysql.connector.connect(
                host=db_config['host'],
                user=db_config['user'],
                password=db_config['password'],
                database=db_config['database']
            )
            return conn
        except mysql.connector.Error as err:
            print(f"Error connecting to database: {err}")
            return None
