import configparser

class DBPropertyUtil:
    @staticmethod
    def getPropertyString(filename):
        config = configparser.ConfigParser()
        config.read(filename)
        if 'DB' in config:
            props = config['DB']
            return {
                'host': props.get('host'),
                'user': props.get('user'),
                'password': props.get('password'),
                'database': props.get('database')
            }
        else:
            raise Exception("DB section not found in properties file.")
