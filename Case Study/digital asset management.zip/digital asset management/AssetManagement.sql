create database assetmanagement;
use assetmanagement;

create table employees(
employee_id int primary key auto_increment,
name varchar(100),
department varchar(50),
email varchar(100) unique,
password varchar(100));

create table assets(
asset_id int primary key auto_increment,
name varchar(100),
type varchar(50),
serial_number varchar(100) unique,
purchase_date date,
location varchar(100),
status varchar(50),
owner_id int,
foreign key(owner_id) references employees(employee_id));

create table maintenance_records(
maintenance_id int primary key auto_increment,
asset_id int,
maintenance_date date,
description text,
cost decimal(10,2),
foreign key(asset_id) references assets(asset_id));


create table asset_allocations(
allocation_id int primary key auto_increment,
asset_id int,
employee_id int,
allocation_date date,
return_date date,
foreign key(asset_id) references assets(asset_id),
foreign key(employee_id) references employees(employee_id));

create table reservations(
reservation_id int primary key auto_increment,
asset_id int,
employee_id int,
reservation_date date,
start_date date,
end_date date,
status varchar(50),
foreign key(asset_id) references assets(asset_id),
foreign key(employee_id) references employees(employee_id));

insert into employees(name,department,email,password) values
('yuvasri','it','yuva@gmail.com','pass123'),
('arjun','hr','arjun@gmail.com','arjun@123'),
('meena','admin','meena@gmail.com','meena456'),
('karthik','finance','karthik@gmail.com','karthik789'),
('divya','it','divya@gmail.com','divya321'),
('ravi','support','ravi@gmail.com','ravi987'),
('anjali','logistics','anjali@gmail.com','anjali456');

insert into assets(name,type,serial_number,purchase_date,location,status,owner_id) values
('dell laptop','laptop','sn1234','2022-01-01','karur office','in use',1),
('hp printer','printer','sn4567','2021-07-15','namakkal branch','under maintenance',2),
('projector','electronics','sn8901','2020-12-20','head office','in use',3),
('macbook air','laptop','sn7788','2023-02-12','coimbatore office','in use',4),
('canon camera','camera','sn4455','2021-03-10','karur office','decommissioned',5),
('epson scanner','scanner','sn6677','2022-06-20','support center','in use',6),
('samsung monitor','monitor','sn8899','2024-01-05','logistics hub','in use',7);

insert into maintenance_records(asset_id,maintenance_date,description,cost) values
(1,'2023-03-15','battery replacement',1500.00),
(2,'2022-10-10','ink refill and cleaning',500.00),
(3,'2021-01-01','lens cleaning',800.00),
(4,'2024-01-20','ssd upgrade',2200.00),
(5,'2021-12-15','camera lens fix',900.00),
(6,'2023-05-10','roller adjustment',600.00),
(7,'2024-04-05','display panel clean',300.00);

insert into asset_allocations(asset_id,employee_id,allocation_date,return_date) values
(1,1,'2023-06-01',null),
(2,2,'2022-05-01','2023-01-15'),
(3,3,'2024-05-01',null),
(4,4,'2024-03-01',null),
(5,5,'2022-07-10','2023-07-10'),
(6,6,'2023-09-05',null),
(7,7,'2024-04-10',null);

insert into reservations(asset_id,employee_id,reservation_date,start_date,end_date,status) values
(3,3,'2023-10-01','2023-10-05','2023-10-10','approved'),
(1,2,'2024-01-01','2024-01-10','2024-01-20','pending'),
(4,1,'2024-02-05','2024-02-10','2024-02-15','approved'),
(5,4,'2023-08-12','2023-08-15','2023-08-20','canceled'),
(6,6,'2023-11-22','2023-11-25','2023-11-30','approved'),
(7,7,'2024-05-01','2024-05-05','2024-05-10','pending'),
(2,5,'2023-03-10','2023-03-15','2023-03-20','approved');



