from dao.AssetManagementServiceImpl import AssetManagementServiceImpl
from entity.Asset import Asset
from datetime import datetime
def main():
    service=AssetManagementServiceImpl()
    while True:
        print("\n====== Digital Asset Management System ======")
        print("1.Add Asset")
        print("2.Update Asset")
        print("3.Delete Asset")
        print("4.Allocate Asset")
        print("5.Deallocate Asset")
        print("6.Perform Maintenance")
        print("7.Reserve Asset")
        print("8.Withdraw Reservation")
        print("9.Exit")
        choice=input("Enter your choice:")
        if choice=="1":
            name=input("Enter asset name:")
            type_=input("Enter asset type:")
            serial_number=input("Enter serial number:")
            purchase_date=input("Enter purchase date (YYYY-MM-DD):")
            location=input("Enter location:")
            status=input("Enter status like in use, under maintenance:")
            owner_id=int(input("Enter owner employee ID:"))
            asset=Asset(0,name,type_,serial_number,purchase_date,location,status,owner_id)
            service.addAsset(asset)
        elif choice=="2":
            asset_id=int(input("Enter asset ID to update:"))
            name=input("Enter new asset name:")
            type_=input("Enter new asset type:")
            serial_number=input("Enter new serial number:")
            purchase_date=input("Enter new purchase date (YYYY-MM-DD):")
            location=input("Enter new location:")
            status=input("Enter new status:")
            owner_id=int(input("Enter new owner ID:"))
            asset=Asset(asset_id,name,type_,serial_number,purchase_date,location,status,owner_id)
            service.updateAsset(asset)
        elif choice=="3":
            asset_id=int(input("Enter asset ID to delete:"))
            service.deleteAsset(asset_id)
        elif choice=="4":
            asset_id=int(input("Enter asset ID to allocate:"))
            employee_id=int(input("Enter employee ID:"))
            allocation_date=input("Enter allocation date (YYYY-MM-DD):")
            service.allocateAsset(asset_id,employee_id,allocation_date)
        elif choice=="5":
            asset_id=int(input("Enter asset ID to deallocate:"))
            employee_id=int(input("Enter employee ID: "))
            return_date=input("Enter return date (YYYY-MM-DD):")
            service.deallocateAsset(asset_id,employee_id,return_date)
        elif choice=="6":
            asset_id=int(input("Enter asset ID for maintenance:"))
            maintenance_date=datetime.strptime(input("Enter maintenance date (YYYY-MM-DD):"),"%Y-%m-%d").date()
            description=input("Enter maintenance description:")
            cost=float(input("Enter maintenance cost:"))
            service.performMaintenance(asset_id,maintenance_date,description,cost)
        elif choice=="7":
            asset_id=int(input("Enter asset ID to reserve:"))
            employee_id=int(input("Enter employee ID:"))
            reservation_date=input("Enter reservation date (YYYY-MM-DD):")
            start_date=input("Enter start date (YYYY-MM-DD):")
            end_date=input("Enter end date (YYYY-MM-DD):")
            service.reserveAsset(asset_id,employee_id,reservation_date,start_date,end_date)
        elif choice=="8":
            reservation_id=int(input("Enter reservation ID to withdraw:"))
            service.withdrawReservation(reservation_id)
        elif choice=="9":
            print("Exiting")
            break
        else:
            print("Invalid choice. Please try again")

if __name__=="__main__":
    main()
